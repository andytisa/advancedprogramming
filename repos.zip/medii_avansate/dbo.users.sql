﻿CREATE TABLE [dbo].[users] (
    [iduser]       INT          IDENTITY (1, 1) NOT NULL,
    [nume]         VARCHAR (50) NOT NULL,
    [adresa]       VARCHAR (50) NOT NULL,
    [email]        VARCHAR (50) NOT NULL,
    [parola]       VARCHAR (50) NOT NULL,
    [idlocalitate] INT          NOT NULL,
    CONSTRAINT [PK_Table] PRIMARY KEY CLUSTERED ([iduser] ASC)
);

