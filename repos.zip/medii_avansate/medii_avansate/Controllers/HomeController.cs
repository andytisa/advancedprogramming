﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace medii_avansate.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to ASP.NET MVC!";
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult HelloWorld()
        {
            //instantiem modelul
            Models.HelloModel model = new Models.HelloModel();
            //punem in ViewData mesajul pe care vrem sa il afisam
            ViewData["msg"] = model.SayHelloWorld();
            //afisam view-ul in varianta explicita : Numele view-ului
            return View("HelloWorld");
        }
        public ActionResult Hello(string nume)
        {
            //instantiem modelul
            Models.HelloModel model = new Models.HelloModel(nume);
            //punem in ViewData mesajul pe care vrem sa il afisam
            ViewData["msg"] = model.SayHello();

            return View(model);
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}