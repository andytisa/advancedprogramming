﻿using medii_avansate.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace medii_avansate.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        public ActionResult Index()
        {
            return View();
        }
        //URL: localhost:[port]/Test/InsertClient
        public ActionResult InsertClient()
        {//introduce doi clienti noi in bd
            Models.Repositories.userRepository clientirepo = new
           Models.Repositories.userRepository();
            //creaza instantele de user
            user newclient = new user();
            newclient.nume = "Smith John";
            newclient.idlocalitate = 1;
            newclient.adresa = "Str. Test 21";
            newclient.email = "johnsmith@email.com";
            newclient.parola = "john";
            user newclient1 = new user();
            newclient1.nume = "Anne Jonson";
            newclient1.idlocalitate = 1;
            newclient1.adresa = "Str.W21 Nr 3";
            newclient1.email = "annej@email.com";
            newclient1.parola = "annej";
            //adauga userii la repository
            clientirepo.AddClient(newclient);
            clientirepo.AddClient(newclient1);
            //salveaza schimbarile
            clientirepo.Save();
            ViewData["msg"] = "Done!";
            return View("Test");
        }
        //URL: localhost:[port]/Test/UpdateClient
        public ActionResult UpdateClient()
        {//face update la clientul cu idclient=1
            Models.Repositories.userRepository clientirepo = new
           Models.Repositories.userRepository();
            //incarca clientul cu id-ul 5 - verificati daca exista id-ul in bd
            user cl = clientirepo.GetClientById(1);
            //face schimbarile
            cl.nume = "Jay Samuel";
            //salveaza schimbarile
            clientirepo.Save();
            ViewData["msg"] = "Updated!";
            return View("Test");
        }
        //URL: localhost:[port]/Test/DeleteClient
        public ActionResult DeleteClient()
        {//sterge clientul cu idclient=2
            Models.Repositories.userRepository clientirepo = new
           Models.Repositories.userRepository();
            //incarca clientul
            user cl = clientirepo.GetClientById(5);
            //sterge clientul
            clientirepo.DeleteClient(cl);
            //salveaza schimbarile
            clientirepo.Save();
            ViewData["msg"] = "Deleted!";
            return View("Test");
        }
    }
}