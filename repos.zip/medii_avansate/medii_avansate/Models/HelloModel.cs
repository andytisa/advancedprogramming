﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace medii_avansate.Models
{
    public class HelloModel
    {
        public string nume;
        public HelloModel()
        {
            //constructorul implicit al clasei model
        }
        public HelloModel(string name) //constructor supraincarcat
        {
            nume = name;
        }
        public string SayHelloWorld() //functioneaza indiferent de constructorul utilizat
        {
            return "Hello World!";
            }
        public string SayHello() //necesita instantierea clasei utilizand constructorul supraincarcat
        {
            return "Hello "+ nume;
        }
    }
}