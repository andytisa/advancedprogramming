﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using medii_avansate.Models;
namespace medii_avansate.Models.Repositories
{
    public class userRepository
    {
        private onlineshopDataContext db = new onlineshopDataContext();
        public IQueryable<user> GetAllClients()
        {
            return db.users; //echivalent cu Select all from users
        }
        public user GetClientByCredentials(string username, string password) //preiadupa email si parola
        {
 return db.users.SingleOrDefault<user>(d => (d.email == username & d.parola == password));
 }
    public user GetClientById(int idusr) //preluare dupa cheia primara
    {
        return db.users.SingleOrDefault<user>(d => d.iduser == idusr);
    }
    public void AddClient(user usr) //inserare user nou
    {
        db.users.InsertOnSubmit(usr);
    }
    public void DeleteClient(user usr) //stergere user
    {
        db.comenzis.DeleteAllOnSubmit<comenzi>(usr.comenzis); //se sterg intai        inregistrarile din tabela copil
        db.users.DeleteOnSubmit(usr); //se sterge inregistrarea din tabela perinte
    }
    public void Save() //salvarea modificarilor pentru persistenta
    {
        db.SubmitChanges();
    }
}
}