﻿CREATE TABLE [dbo].[comenzi] (
    [Id]           INT        NOT NULL,
    [idcomanda]    INT        NOT NULL,
    [iduser]       INT        NOT NULL,
    [idpordus]     INT        NOT NULL,
    [cantitate]    INT        NOT NULL,
    [data_comanda] DATETIME   NOT NULL,
    [suma_plata]   FLOAT (53) NOT NULL,
    [onorata]      BIT        NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([iduser]) REFERENCES [dbo].[users] ([iduser])
);

