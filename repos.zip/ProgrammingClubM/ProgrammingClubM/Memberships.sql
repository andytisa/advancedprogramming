﻿CREATE TABLE Memberships
(
	[IDMembership] INT NOT NULL PRIMARY KEY, 
    [IDMember] UNIQUEIDENTIFIER NOT NULL, 
    [IDMembershipType] UNIQUEIDENTIFIER NOT NULL, 
    [StartDate] DATETIME NOT NULL, 
    [EndDate] DATETIME NULL, 
    [Level] INT NOT NULL DEFAULT 0,

    CONSTRAINT [FK_Memberships_MembershipTypes] FOREIGN KEY ([IDMembershipType]) REFERENCES [MembershipTypes]([IDMembershipType]),
    CONSTRAINT [FK_Memberships_Members] FOREIGN KEY ([IDMember]) REFERENCES [Members]([IDMember]),
)
