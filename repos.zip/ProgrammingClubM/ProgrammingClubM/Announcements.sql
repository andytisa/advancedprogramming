﻿CREATE TABLE Announcements
(
	[IDAnnouncement] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY, 
    [ValidFrom] DATETIME NOT NULL, 
    [ValidTo] DATETIME NOT NULL, 
    [Title] VARCHAR(1000) NOT NULL, 
    [Text] VARCHAR(1000) NOT NULL, 
    [EventDateTime] DATETIME NULL, 
    [Tags] VARCHAR(1000) NULL
)
