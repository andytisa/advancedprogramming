﻿CREATE TABLE CodeSnippets
(
	[IDCodeSnippet] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY, 
    [Title] VARCHAR(100) NOT NULL, 
    [ContentCode] VARCHAR(MAX) NOT NULL, 
    [IDMember] UNIQUEIDENTIFIER NOT NULL, 
    [Revision] INT NOT NULL DEFAULT 0, 
    [IDSNippetPreviousVersion] UNIQUEIDENTIFIER NULL, 
    [DateTimeAdded] DATETIME NOT NULL, 
    [IsPublished] BIT NOT NULL, 
    CONSTRAINT [FK_CodeSnippets_Members] FOREIGN KEY ([IDMember]) REFERENCES [Members]([IDMember]),
    CONSTRAINT [FK_CodeSnippets_CodeSnippets] FOREIGN KEY ([IDSNippetPreviousVersion]) 
    REFERENCES CodeSnippets(IDCodeSnippet)
)
