﻿CREATE TABLE MembershipTypes
(
	[IDMembershipType] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY, 
    [Name] VARCHAR(100) NOT NULL, 
    [Description] VARCHAR(250) NOT NULL, 
    [SubscriptionLengthInMonths] INT NOT NULL
)
