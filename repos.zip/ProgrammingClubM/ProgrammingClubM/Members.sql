﻿CREATE TABLE Members
(
	[IDMember] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY, 
    [Name] NCHAR(10) NOT NULL, 
    [Title] NCHAR(10) NOT NULL, 
    [Position] NCHAR(10) NOT NULL, 
    [Description] NCHAR(10) NULL, 
    [Resume] NCHAR(10) NULL
)
